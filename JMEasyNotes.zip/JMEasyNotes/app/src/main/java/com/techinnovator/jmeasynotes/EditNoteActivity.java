package com.techinnovator.jmeasynotes;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.transition.TransitionManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class EditNoteActivity extends AppCompatActivity {

    EditText etTitle;
    EditText etDesc;
    Button save;
    Button cancel;
    LinearLayout btnHolder;
    int id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setTitle("Edit Note");
        setContentView(R.layout.activity_edit_note);

        Intent intent = getIntent();
        etTitle = findViewById(R.id.etUpdateTitle);
        etDesc = findViewById(R.id.etUpdateDesc);
        save = findViewById(R.id.btnSave);
        cancel = findViewById(R.id.btnCancel);
        btnHolder = findViewById(R.id.btnHolder);

        String noteTitle = intent.getStringExtra("title");
        String noteDesc = intent.getStringExtra("desc");
        String noteDate = intent.getStringExtra("date");
        id = intent.getIntExtra("id", 1);

        etTitle.setText(intent.getStringExtra("title"));
        etDesc.setText(intent.getStringExtra("desc"));

        etTitle.requestFocus();

        save.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                Date dateObj = new Date();
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("hh:mm aa, dd-MM-yyyy");
                String date = simpleDateFormat.format(dateObj);

                Note note;

                if(etTitle.getText().toString().equals("") && etDesc.getText().toString().equals("")){
//                    note = new Note(etTitle.getText().toString(), etDesc.getText().toString(), date);
//                    note.setId(intent.getIntExtra("id", 1));
                    new NoteHandler(EditNoteActivity.this).delete(id);
                }
                else if(!etTitle.getText().toString().equals(noteTitle) || !etDesc.getText().toString().equals(noteDesc)) {
//                    note = new Note(etTitle.getText().toString(), etDesc.getText().toString(), noteDate);
                    note = new Note(etTitle.getText().toString(), etDesc.getText().toString(), date);

                    note.setId(intent.getIntExtra("id", 1));

                    if (new NoteHandler(EditNoteActivity.this).update(note)) {
//                        Toast.makeText(EditNoteActivity.this, "Updated Successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(EditNoteActivity.this, "Failed Updating", Toast.LENGTH_SHORT).show();
                    }
                }
                onBackPressed();
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.delete_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        new AlertDialog.Builder(EditNoteActivity.this).setTitle("Delete note").setMessage("Delete this note?").setIcon(R.drawable.ic_delete_black)
                .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        new NoteHandler(EditNoteActivity.this).delete(id);
                        Toast.makeText(EditNoteActivity.this, "Deleted Successfully", Toast.LENGTH_SHORT).show();
                        onBackPressed();
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        }).setCancelable(false).show();
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        save.setVisibility(View.GONE);
        cancel.setVisibility(View.GONE);
        TransitionManager.beginDelayedTransition(btnHolder);
        super.onBackPressed();
    }
}