package com.techinnovator.jmeasynotes;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.app.ActivityOptionsCompat;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    ImageButton imageButton;
    ArrayList<Note> notes;
    RecyclerView recyclerView;
    NoteAdapter noteAdapter;
    ImageView imgLogo;
    LocalDate date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageButton = findViewById(R.id.imgAdd);
        imgLogo = findViewById(R.id.imgLogo);

        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                LayoutInflater layoutInflater = (LayoutInflater) MainActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//                View view = layoutInflater.inflate(R.layout.note_input, null, false);

                View view = LayoutInflater.from(MainActivity.this).inflate(R.layout.note_input, null, false);

                EditText etTitle = view.findViewById(R.id.etTitle);
                EditText etDesc = view.findViewById(R.id.etDesc);

                etTitle.requestFocus();

                new AlertDialog.Builder(MainActivity.this).setView(view).setTitle("Add Note").setPositiveButton("Add", new DialogInterface.OnClickListener() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
//                        LocalDateTime dateObj = LocalDateTime.now();
//                        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy, HH:mm");
                        if(!etTitle.getText().toString().equals("") || !etDesc.getText().toString().equals("")){
                            Date dateObj = new Date();
                            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("hh:mm aa, dd-MM-yyyy");
                            String date = simpleDateFormat.format(dateObj);
//                        String date = dateObj.format(dateTimeFormatter);

                            Note note = new Note(etTitle.getText().toString(), etDesc.getText().toString(), date);

                            boolean isInserted = new NoteHandler(MainActivity.this).create(note);
                            if(isInserted){
//                                Toast.makeText(MainActivity.this, "Note Saved", Toast.LENGTH_SHORT).show();
                                loadNotes();
                            }
                            else{
                                Toast.makeText(MainActivity.this, "Unable to save the note", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else{
//                            Toast.makeText(MainActivity.this, "Enter Title or Description", Toast.LENGTH_SHORT).show();
                        }

                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                }).setCancelable(false).show();

            }
        });
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                new NoteHandler(MainActivity.this).delete(notes.get(viewHolder.getAdapterPosition()).getId());
                notes.remove(viewHolder.getAdapterPosition());
                noteAdapter.notifyDataSetChanged();
                if(notes.size()>0){
                    imgLogo.setVisibility(View.GONE);
                }
                else if(notes.size()==0){
                    imgLogo.setVisibility(View.VISIBLE);
                }
//                Toast.makeText(MainActivity.this, "Note is Deleted", Toast.LENGTH_SHORT).show();
            }
        };

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
        itemTouchHelper.attachToRecyclerView(recyclerView);

        loadNotes();
    }
    public ArrayList<Note> readNotes(){
        ArrayList<Note> arr = new NoteHandler(this).readNotes();
        return arr;
    }
    public void loadNotes(){
        notes = readNotes();
        if(notes.size()>0){
            imgLogo.setVisibility(View.GONE);
        }
        else if(notes.size()==0){
            imgLogo.setVisibility(View.VISIBLE);
        }
        noteAdapter = new NoteAdapter(this, notes, new NoteAdapter.ItemClicked(){

            @Override
            public void onClick(int pos, View view) {
                editNote(notes.get(pos).getId(), view);
            }
        });
        recyclerView.setAdapter(noteAdapter);
    }
    public void editNote(int noteId, View view){
        Note note = new NoteHandler(this).readSingleNote(noteId);

        Intent intent = new Intent(this, EditNoteActivity.class);
        intent.putExtra("title", note.getTitle());
        intent.putExtra("desc", note.getDesc());
        intent.putExtra("id", note.getId());
        intent.putExtra("date", note.getDate());

        ActivityOptionsCompat activityOptionsCompat = ActivityOptionsCompat.makeSceneTransitionAnimation(this, view, ViewCompat.getTransitionName(view));
        startActivityForResult(intent, 1, activityOptionsCompat.toBundle());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==1){
            loadNotes();
        }
    }
}